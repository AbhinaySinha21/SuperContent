let th=document.querySelectorAll("input[name='the']");
const u="https://api.tvmaze.com/search/shows?q=";

th.forEach((demo)=>{
    demo.addEventListener('click',(e)=>{
        if(e.target.id==="black")
            document.querySelector(".search h1").style.color="white";
        else
            document.querySelector(".search h1").style.color="black";
        document.querySelector(":root").style.setProperty('--main-col',demo.id);
        localStorage.setItem('color',demo.id);
    });
});

window.addEventListener('load',()=>{
    let the=localStorage.getItem('color');
    document.querySelector(":root").style.setProperty('--main-col',the);
    let check=document.getElementById(the);
    check.checked=true;
});

/* API call */
btn=document.getElementById("sit");
btn.addEventListener("click",(e)=>{
    if(document.getElementById("movie").childNodes.length>0){
        removeAllChildNodes(document.getElementById("movie"));
    }
    e.preventDefault();
    let tosearch=document.getElementById("sL").value;
    document.getElementById("sL").value="";
    fetch(u+tosearch).then((res)=>{
        return res.json();
    }).then((data)=>{
        displayI(data);
    });
});

function displayI(data){
    data.forEach((demo)=>{
        let div=document.createElement("div");
        let img=document.createElement("img");
        img.setAttribute("src",demo.show.image.original);
        img.setAttribute("width","300px");
        img.setAttribute("height","500px");
        div.appendChild(img);
        div.className="image";
        document.getElementById("movie").appendChild(div);
    });
}
function removeAllChildNodes(p) {
    while (p.firstChild) {
        p.removeChild(p.firstChild);
    }
}
